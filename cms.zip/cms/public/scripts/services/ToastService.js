'use strict';

/**
 * @ngdoc service
 * @name nearPlaceAppApp.servicioToast
 * @description
 * # servicioToast
 * Service in the nearPlaceAppApp.
 */
 angular.module('nearPlaceApp')
 .service('Toast', function () {

 	var toastPosition = {
 		bottom: false,
 		top: true,
 		left: false,
 		right: true
 	};

 });
